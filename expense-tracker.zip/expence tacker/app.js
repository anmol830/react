import React, { useState } from 'react';
import './styles.css';

export default function App() {
  // State for user authentication
  const [user, setUser] = useState({ loggedIn: false, name: '' });

  // State for login input field
  const [loginName, setLoginName] = useState('');

  // State for expense input fields
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');

  // State to store all expenses
  const [expenses, setExpenses] = useState([]);

  // To track whether we are editing an existing expense
  const [editIndex, setEditIndex] = useState(null);

  // Handle login
  const handleLogin = () => {
    if (loginName.trim() === '') return; // Avoid empty login
    setUser({ loggedIn: true, name: loginName.trim() });
    setLoginName('');
  };

  // Handle logout
  const handleLogout = () => {
    setUser({ loggedIn: false, name: '' });
    setExpenses([]);
    setDescription('');
    setAmount('');
    setEditIndex(null);
  };

  // Add or update an expense
  const handleAddExpense = () => {
    if (!description || !amount) return;

    const newExpense = {
      description,
      amount: parseFloat(amount),
    };

    if (editIndex !== null) {
      // Update existing
      const updated = [...expenses];
      updated[editIndex] = newExpense;
      setExpenses(updated);
      setEditIndex(null);
    } else {
      // Add new
      setExpenses([...expenses, newExpense]);
    }

    // Reset input fields
    setDescription('');
    setAmount('');
  };

  // Prepare edit mode
  const handleEditExpense = (index) => {
    const expense = expenses[index];
    setDescription(expense.description);
    setAmount(expense.amount);
    setEditIndex(index);
  };

  // Delete expense
  const handleDeleteExpense = (index) => {
    const filtered = expenses.filter((_, i) => i !== index);
    setExpenses(filtered);
    setEditIndex(null);
  };

  // Total calculation
  const getTotal = () => {
    return expenses.reduce((sum, e) => sum + e.amount, 0);
  };

  // For chart visualization
  const getChartData = () => {
    const total = getTotal();
    return expenses.map((e) => ({
      ...e,
      percent: total === 0 ? 0 : Math.round((e.amount / total) * 100),
    }));
  };

  // Show login screen if not logged in
  if (!user.loggedIn) {
    return (
      <div className="app-container">
        <h2>Login to Expense Tracker</h2>
        <input
          type="text"
          placeholder="Enter your name"
          value={loginName}
          onChange={(e) => setLoginName(e.target.value)}
        />
        <button onClick={handleLogin}>Login</button>
      </div>
    );
  }

  // Show expense tracker UI
  return (
    <div className="app-container">
      <div className="user-info">
        <p>Welcome, {user.name}</p>
        <button onClick={handleLogout}>Logout</button>
      </div>

      <div className="expense-form">
        <input
          type="text"
          placeholder="Description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />
        <input
          type="number"
          placeholder="Amount"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        />
        <button onClick={handleAddExpense}>
          {editIndex !== null ? 'Update Expense' : 'Add Expense'}
        </button>
      </div>

      <ul className="expense-list">
        {expenses.map((e, index) => (
          <li key={index}>
            <span>{e.description}: ₹{e.amount.toFixed(2)}</span>
            <div>
              <button onClick={() => handleEditExpense(index)}>Edit</button>
              <button onClick={() => handleDeleteExpense(index)}>Delete</button>
            </div>
          </li>
        ))}
      </ul>

      <h3>Total Spent: ₹{getTotal().toFixed(2)}</h3>

      <div className="chart">
        {getChartData().map((item, index) => (
          <div key={index} className="bar">
            <span>{item.description} ({item.percent}%)</span>
            <div
              className="bar-amount"
              style={{ width: `${item.percent}%` }}
            >
              ₹{item.amount.toFixed(2)}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
